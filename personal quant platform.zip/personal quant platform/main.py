# --- 保留你原有的 import 和函数 ---
import tkinter.ttk as ttk
from utils.config import *
from factors.momentum import calc_momentum, time_series_zscore
from strategies.momentum_strategy import generate_signal_momentum
from strategies.moving_average import generate_signal_ma
from backtest.engine import backtest_single
from utils.plot import plot_price_signals
from strategies.volume_strategy import generate_signal_volume
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, filedialog
import pandas as pd
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from factors.rsi import calc_rsi
from strategies.rsi_strategy import generate_signal_rsi
import tkinter.ttk as ttk



def safe_window(w, n):
    return min(max(2, w), max(2, n//2 if n//2 >= 2 else n))

def load_clean_csv(filepath):
    return pd.read_csv(filepath, skiprows=[1])

def plot_kline(df, root, title="K线图"):
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(df["date"], df["close"], label="收盘价", color="blue")
    ax.set_title(title)
    ax.set_xlabel("日期")
    ax.set_ylabel("收盘价")
    ax.legend()
    fig.autofmt_xdate()
    for widget in root.pack_slaves():
        if isinstance(widget, FigureCanvasTkAgg):
            widget.get_tk_widget().destroy()
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()
    canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

def run_selected_strategies(selected, csv_path):
    df = load_clean_csv(csv_path)
    close = df["close"]
    volume = df["volume"]
    n = len(close)
    mom_w = safe_window(MOM_WINDOW, n)
    vol_w = safe_window(VOL_WINDOW, n)
    ma_s = min(MA_SHORT, max(1, n-1))
    ma_l = min(MA_LONG, max(ma_s+1, n-1))
    OUT_DIR.mkdir(exist_ok=True)
    results = []
    if "momentum" in selected:
        momentum = calc_momentum(close, mom_w)
        mom_z = time_series_zscore(momentum, mom_w)
        signal_mom = generate_signal_momentum(mom_z)
        out_mom = backtest_single(close, signal_mom, INITIAL_CAPITAL, FEE_PERC, TRADING_DAYS)
        out_mom["equity"].to_csv(OUT_DIR / "equity_mom.csv", encoding="utf-8-sig")
        plot_price_signals(close, signal_mom, "动量策略买卖点", OUT_DIR / "price_signal_mom.png")
        results.append(f"Momentum: total_return={out_mom['total_return']:.2%}, sharpe={out_mom['sharpe']:.2f}")
    if "ma" in selected:
        signal_ma = generate_signal_ma(close, ma_s, ma_l)
        out_ma = backtest_single(close, signal_ma, INITIAL_CAPITAL, FEE_PERC, TRADING_DAYS)
        out_ma["equity"].to_csv(OUT_DIR / "equity_ma.csv", encoding="utf-8-sig")
        plot_price_signals(close, signal_ma, "均线策略买卖点", OUT_DIR / "price_signal_ma.png")
        results.append(f"MA: total_return={out_ma['total_return']:.2%}, sharpe={out_ma['sharpe']:.2f}")
    if "volume" in selected:
        signal_vol = generate_signal_volume(volume, window=VOL_WINDOW, threshold=2.0)
        out_vol = backtest_single(close, signal_vol, INITIAL_CAPITAL, FEE_PERC, TRADING_DAYS)
        out_vol["equity"].to_csv(OUT_DIR / "equity_volume.csv", encoding="utf-8-sig")
        plot_price_signals(close, signal_vol, "成交量策略买卖点", OUT_DIR / "price_signal_volume.png")
        results.append(f"Volume: total_return={out_vol['total_return']:.2%}, sharpe={out_vol['sharpe']:.2f}")
    if "rsi" in selected:
        rsi = calc_rsi(close, period=14)
        signal_rsi = generate_signal_rsi(rsi)
        out_rsi = backtest_single(close, signal_rsi, INITIAL_CAPITAL, FEE_PERC, TRADING_DAYS)
        out_rsi["equity"].to_csv(OUT_DIR / "equity_rsi.csv", encoding="utf-8-sig")
        plot_price_signals(close, signal_rsi, "RSI策略买卖点", OUT_DIR / "price_signal_rsi.png")
        results.append(f"RSI: total_return={out_rsi['total_return']:.2%}, sharpe={out_rsi['sharpe']:.2f}")
    return results

# --- 新增组合回测功能 ---
def run_portfolio_backtest(selected, folder_path, initial_capital=200000):
    files = list(Path(folder_path).glob("*.csv"))
    if not files:
        return ["未找到CSV文件！"]

    # 读取所有股票数据
    stock_data = {}
    for f in files:
        df = load_clean_csv(f)
        code = df["股票代码"].iloc[0]
        df = df.sort_values("date").reset_index(drop=True)
        stock_data[code] = df

    cash = initial_capital
    positions = {}
    portfolio_value_history = []
    
    # 用于记录每天的信号
    portfolio_signals = {code: [] for code in stock_data}

    # 构建完整交易日历
    trading_calendar = sorted(set().union(*[df["date"] for df in stock_data.values()]))

    for date in trading_calendar:
        for code, df in stock_data.items():
            if date not in list(df["date"]):
                portfolio_signals[code].append(0)  # 没有信号
                continue
            row = df[df["date"]==date].iloc[0]
            close = row["close"]
            volume = row["volume"]
            n = len(df)
            signals = []

            # 调用策略
            if "momentum" in selected:
                mom_w = safe_window(MOM_WINDOW, n)
                momentum = calc_momentum(df["close"], mom_w)
                mom_z = time_series_zscore(momentum, mom_w)
                signal_mom = generate_signal_momentum(mom_z)
                signals.append(signal_mom.loc[df["date"]==date].values[0])
            if "ma" in selected:
                signal_ma = generate_signal_ma(df["close"], MA_SHORT, MA_LONG)
                signals.append(signal_ma.loc[df["date"]==date].values[0])
            if "volume" in selected:
                signal_vol = generate_signal_volume(df["volume"], window=VOL_WINDOW, threshold=2.0)
                signals.append(signal_vol.loc[df["date"]==date].values[0])
            if "rsi" in selected:
                rsi = calc_rsi(df["close"], period=14)
                signal_rsi = generate_signal_rsi(rsi)
                signals.append(signal_rsi.loc[df["date"]==date].values[0])

            # 多策略融合
            if signals:
                final_signal = sum(signals)/len(signals)
                final_signal = 1 if final_signal>0 else (-1 if final_signal<0 else 0)
            else:
                final_signal = 0

            # 执行买卖
            if final_signal == 1 and code not in positions:
                allocation = cash / len(stock_data)
                shares = int(allocation / close)
                if shares>0:
                    positions[code] = {"shares": shares, "cost": close}
                    cash -= shares*close
            elif final_signal == -1 and code in positions:
                shares = positions[code]["shares"]
                cash += shares*close
                del positions[code]

            # 记录当天信号
            portfolio_signals[code].append(final_signal)

        # 更新总市值
        total_value = cash
        for code, pos in positions.items():
            last_close = stock_data[code][stock_data[code]["date"]==date]["close"].values[0]
            total_value += pos["shares"]*last_close
        portfolio_value_history.append((date, total_value))

    # 保存组合净值
    df_portfolio = pd.DataFrame(portfolio_value_history, columns=["date","portfolio_value"])
    df_portfolio.to_csv(OUT_DIR/"portfolio_equity.csv", index=False, encoding="utf-8-sig")

    # 绘制每只股票信号图
    for code, df in stock_data.items():
        signals_series = pd.Series(portfolio_signals[code], index=df["date"])
        plot_price_signals(df["close"], signals_series, title=f"{code}组合回测买卖点",
                           filename=OUT_DIR/f"{code}_portfolio_signal.png")

    total_return = df_portfolio["portfolio_value"].iloc[-1]/initial_capital-1
    return [f"Portfolio: total_return={total_return:.2%}, 最终市值={df_portfolio['portfolio_value'].iloc[-1]:.2f}"]



# --- main GUI ---
def main():
    root = tk.Tk()
    root.title("策略选择与回测")
    root.geometry("1000x700")
    root.configure(bg="#f0f2f5")

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("TButton", font=("Arial", 11, "bold"))
    style.configure("TCheckbutton", font=("Arial", 11))
    style.configure("TLabelframe", font=("Arial", 11, "bold"))

    csv_path = tk.StringVar()
    df_cache = {}

    # ====== 公共部分 ======
    var_mom = tk.BooleanVar()
    var_ma = tk.BooleanVar()
    var_vol = tk.BooleanVar()
    var_rsi = tk.BooleanVar()

    def get_selected_strategies():
        selected = []
        if var_mom.get(): selected.append("momentum")
        if var_ma.get(): selected.append("ma")
        if var_vol.get(): selected.append("volume")
        if var_rsi.get(): selected.append("rsi")
        return selected

    # ====== 单股回测函数 ======
    def select_file():
        path = filedialog.askopenfilename(title="选择CSV数据文件", filetypes=[("CSV文件", "*.csv")])
        if path:
            csv_path.set(path)
            result_label.config(text=f"已选择文件：{path}")
            df = load_clean_csv(path)
            df_cache["df"] = df
            plot_kline(df, frame_plot, title=f"{df['股票代码'].iloc[0]} K线图")

    def on_run_single():
        selected = get_selected_strategies()
        if not selected:
            messagebox.showwarning("提示", "请至少选择一个策略！")
            return
        if not csv_path.get():
            messagebox.showwarning("提示", "请先选择数据文件！")
            return
        results = run_selected_strategies(selected, csv_path.get())
        result_label.config(text="\n".join(results) + f"\n结果文件保存在 {OUT_DIR.resolve()}/")

    # ====== 组合回测函数 ======
    def select_folder():
        path = filedialog.askdirectory(title="选择包含CSV的文件夹")
        if path:
            csv_path.set(path)
            result_label.config(text=f"已选择文件夹：{path}")

    def on_run_portfolio():
        selected = get_selected_strategies()
        if not selected:
            messagebox.showwarning("提示", "请至少选择一个策略！")
            return
        if not csv_path.get():
            messagebox.showwarning("提示", "请先选择CSV文件夹！")
            return
        results = run_portfolio_backtest(selected, csv_path.get(), initial_capital=200000)
        result_label.config(text="\n".join(results) + f"\n组合结果文件保存在 {OUT_DIR.resolve()}/")

    # ====== Notebook 结构 ======
    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True, padx=10, pady=10)

    # --- Tab 1 单股回测 ---
    tab_single = ttk.Frame(notebook)
    notebook.add(tab_single, text="单股回测")

    frame_strategies = ttk.LabelFrame(tab_single, text="选择策略", padding=10)
    frame_strategies.pack(fill="x", padx=10, pady=5)
    ttk.Checkbutton(frame_strategies, text="动量策略", variable=var_mom).pack(side="left", padx=5)
    ttk.Checkbutton(frame_strategies, text="均线策略", variable=var_ma).pack(side="left", padx=5)
    ttk.Checkbutton(frame_strategies, text="成交量策略", variable=var_vol).pack(side="left", padx=5)
    ttk.Checkbutton(frame_strategies, text="RSI策略", variable=var_rsi).pack(side="left", padx=5)

    frame_file = ttk.LabelFrame(tab_single, text="数据文件", padding=10)
    frame_file.pack(fill="x", padx=10, pady=5)
    ttk.Button(frame_file, text="选择数据文件", command=select_file).pack(side="left", padx=5)
    ttk.Button(frame_file, text="运行单股回测", command=on_run_single).pack(side="left", padx=5)

    frame_plot = ttk.LabelFrame(tab_single, text="K线图", padding=10)
    frame_plot.pack(fill="both", expand=True, padx=10, pady=5)

    # --- Tab 2 组合回测 ---
    tab_portfolio = ttk.Frame(notebook)
    notebook.add(tab_portfolio, text="组合回测")

    frame_file2 = ttk.LabelFrame(tab_portfolio, text="股票文件夹", padding=10)
    frame_file2.pack(fill="x", padx=10, pady=5)
    ttk.Button(frame_file2, text="选择股票文件夹", command=select_folder).pack(side="left", padx=5)
    ttk.Button(frame_file2, text="运行组合回测", command=on_run_portfolio).pack(side="left", padx=5)

    # --- 底部结果显示 ---
    result_label = tk.Label(root, text="", fg="blue", font=("Arial", 12, "bold"), bg="#f0f2f5", justify="left")
    result_label.pack(fill="x", padx=10, pady=10)

    root.mainloop()


if __name__ == "__main__":
    main()
