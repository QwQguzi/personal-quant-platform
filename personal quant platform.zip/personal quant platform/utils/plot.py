import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.dates as mdates

def plot_price_signals(price, signal, title, filename):
    """漂亮的价格买卖点图"""
    import matplotlib.dates as mdates

    plt.style.use('seaborn-v0_8-darkgrid')
    fig, ax = plt.subplots(figsize=(12, 6))

    # 转 Series 并对齐索引
    price = pd.Series(price)
    signal = pd.Series(signal, index=price.index)

    # X轴
    if pd.api.types.is_datetime64_any_dtype(price.index):
        x = price.index
    else:
        x = range(len(price))

    # 绘制价格线，渐变效果
    ax.plot(x, price.values, label='Close', color='#1f77b4', linewidth=2)

    # 绘制买入卖出点
    buy_points = signal == 1
    sell_points = signal == -1
    ax.scatter(price.index[buy_points], price[buy_points],
               marker='^', color='green', s=120, edgecolors='black', label='Buy')
    ax.scatter(price.index[sell_points], price[sell_points],
               marker='v', color='red', s=120, edgecolors='black', label='Sell')

    # 标题和标签
    ax.set_title(title, fontsize=16)
    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel('Price', fontsize=12)
    ax.legend(fontsize=12)

    # 网格线、透明度
    ax.grid(True, linestyle='--', alpha=0.5)

    # X轴日期格式化
    if pd.api.types.is_datetime64_any_dtype(price.index):
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
        fig.autofmt_xdate(rotation=45)

    plt.tight_layout()
    plt.savefig(filename, dpi=150)
    plt.close()
    print(f"Saved signal plot to {filename}")
