import yfinance as yf
import pandas as pd
import os

data_folder = "data/day_data"
os.makedirs(data_folder, exist_ok=True)

tickers = [
    "AAPL", "MSFT", "AMZN", "TSLA", "NVDA", "GOOGL", "META", "BRK-B", "JPM", "JNJ",
    "V", "UNH", "HD", "PG", "MA", "DIS", "BAC", "XOM", "PFE", "KO",
    "INTC", "CSCO", "PYPL", "NFLX", "NVDA", "AMD", "BA", "CAT", "GS", "IBM",
    "LMT", "MMM", "RTX", "UNH", "WMT", "CVX", "KO", "PEP", "MCD", "NKE",
    "T", "VZ", "WFC", "GS", "MS", "AXP", "SPG", "CCI", "PLD", "AMT",
    "EQIX", "DLR", "PSA", "O", "REG", "MPW", "WPC", "LXP", "SRC", "KIM",
    "SKT", "FRT", "MAC", "SPG", "CCI", "PLD", "AMT", "EQIX", "DLR", "PSA",
    "O", "REG", "MPW", "WPC", "LXP", "SRC", "KIM", "SKT", "FRT", "MAC",
    "SPG", "CCI", "PLD", "AMT", "EQIX", "DLR", "PSA", "O", "REG", "MPW",
    "WPC", "LXP", "SRC", "KIM", "SKT", "FRT", "MAC", "SPG", "CCI", "PLD",
    "AMT", "EQIX", "DLR", "PSA", "O", "REG", "MPW", "WPC", "LXP", "SRC",
    "KIM", "SKT", "FRT", "MAC", "SPG", "CCI", "PLD", "AMT", "EQIX", "DLR",
    "PSA", "O", "REG", "MPW", "WPC", "LXP", "SRC", "KIM", "SKT", "FRT", "MAC",
    "SPG", "CCI", "PLD", "AMT", "EQIX", "DLR", "PSA", "O", "REG", "MPW",
    "WPC", "LXP", "SRC", "KIM", "SKT", "FRT", "MAC", "SPG", "CCI", "PLD",
    "AMT", "EQIX", "DLR", "PSA", "O", "REG", "MPW", "WPC", "LXP", "SRC",
    "KIM", "SKT", "FRT", "MAC", "SPG", "CCI", "PLD", "AMT", "EQIX", "DLR",
    "PSA", "O", "REG", "MPW", "WPC", "LXP", "SRC", "KIM", "SKT", "FRT", "MAC",
    "SPG", "CCI", "PLD", "AMT", "EQIX", "DLR", "PSA", "O", "REG", "MPW",
    "WPC", "LXP", "SRC", "KIM", "SKT", "FRT", "MAC", "SPG", "CCI", "PLD",
    "AMT", "EQIX", "DLR", "PSA", "O", "REG", "MPW", "WPC", "LXP", "SRC",
    "KIM", "SKT", "FRT", "MAC", "SPG", "CCI", "PLD", "AMT", "EQIX", "DLR",
    "PSA", "O", "REG", "MPW", "WPC", "LXP", "SRC", "KIM", "SKT", "FRT", "MAC"
]

for symbol in tickers:
    try:
        # 下载数据，auto_adjust=True 避免未来警告
        df = yf.download(symbol, period="1y", interval="1d", progress=False, auto_adjust=False)

        # 保证有 Close 和 Volume 列
        if "Close" in df.columns and "Volume" in df.columns:
            df["成交额"] = df["Close"] * df["Volume"]
            df = df[df["成交额"] >= 2e8]  # 筛选成交额 >= 2亿

            if not df.empty:
                df.to_csv(f"{data_folder}/{symbol}.csv", index=True)
                print(f"{symbol} 保存完成，共 {len(df)} 条记录")
            else:
                print(f"{symbol} 没有满足成交额条件的数据")
        else:
            print(f"{symbol} 数据列异常，无法计算成交额")
    except Exception as e:
        print(f"{symbol} 下载失败: {e}")
